from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
import uuid
import sqlite3
from datetime import datetime
from typing import List, Optional
import PyMuPDF  # fitz
from pydantic import BaseModel
import json

app = FastAPI(title="PDF Q&A API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # Vite dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create directories
os.makedirs("uploads", exist_ok=True)
os.makedirs("database", exist_ok=True)

# Database setup
DATABASE_PATH = "database/documents.db"

def init_db():
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            original_filename TEXT NOT NULL,
            upload_date TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            text_content TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS questions (
            id TEXT PRIMARY KEY,
            document_id TEXT NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            FOREIGN KEY (document_id) REFERENCES documents (id)
        )
    """)
    conn.commit()
    conn.close()

init_db()

class QuestionRequest(BaseModel):
    document_id: str
    question: str

class DocumentResponse(BaseModel):
    id: str
    filename: str
    original_filename: str
    upload_date: str
    file_size: int

class QuestionResponse(BaseModel):
    id: str
    question: str
    answer: str
    timestamp: str

def extract_text_from_pdf(file_path: str) -> str:
    """Extract text content from PDF using PyMuPDF"""
    try:
        doc = PyMuPDF.open(file_path)
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()
        return text
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error extracting text from PDF: {str(e)}")

def simple_qa_processor(text_content: str, question: str) -> str:
    """
    Simple Q&A processor - in production, this would use LangChain/LlamaIndex
    For demo purposes, we'll implement basic keyword matching and text search
    """
    question_lower = question.lower()
    text_lower = text_content.lower()
    
    # Split text into sentences
    sentences = [s.strip() for s in text_content.split('.') if s.strip()]
    
    # Find relevant sentences based on question keywords
    question_words = set(question_lower.split())
    relevant_sentences = []
    
    for sentence in sentences:
        sentence_words = set(sentence.lower().split())
        # Calculate overlap between question and sentence
        overlap = len(question_words.intersection(sentence_words))
        if overlap > 0:
            relevant_sentences.append((sentence, overlap))
    
    # Sort by relevance and take top sentences
    relevant_sentences.sort(key=lambda x: x[1], reverse=True)
    
    if relevant_sentences:
        # Return the most relevant sentences
        answer_parts = [sent[0] for sent in relevant_sentences[:3]]
        answer = ". ".join(answer_parts)
        return f"Based on the document content: {answer}"
    else:
        return "I couldn't find relevant information in the document to answer your question. Please try rephrasing your question or ask about different topics covered in the document."

@app.post("/upload", response_model=DocumentResponse)
async def upload_document(file: UploadFile = File(...)):
    """Upload and process PDF document"""
    
    # Validate file type
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    # Generate unique filename
    document_id = str(uuid.uuid4())
    file_extension = os.path.splitext(file.filename)[1]
    filename = f"{document_id}{file_extension}"
    file_path = os.path.join("uploads", filename)
    
    try:
        # Save file
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        
        # Extract text content
        text_content = extract_text_from_pdf(file_path)
        
        # Store in database
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO documents (id, filename, original_filename, upload_date, file_size, text_content)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            document_id,
            filename,
            file.filename,
            datetime.now().isoformat(),
            len(content),
            text_content
        ))
        conn.commit()
        conn.close()
        
        return DocumentResponse(
            id=document_id,
            filename=filename,
            original_filename=file.filename,
            upload_date=datetime.now().isoformat(),
            file_size=len(content)
        )
        
    except Exception as e:
        # Clean up file if database operation fails
        if os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(status_code=500, detail=f"Error processing document: {str(e)}")

@app.post("/ask", response_model=QuestionResponse)
async def ask_question(request: QuestionRequest):
    """Ask a question about an uploaded document"""
    
    # Get document from database
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT text_content FROM documents WHERE id = ?", (request.document_id,))
    result = cursor.fetchone()
    
    if not result:
        conn.close()
        raise HTTPException(status_code=404, detail="Document not found")
    
    text_content = result[0]
    
    # Process question and generate answer
    answer = simple_qa_processor(text_content, request.question)
    
    # Store question and answer
    question_id = str(uuid.uuid4())
    cursor.execute("""
        INSERT INTO questions (id, document_id, question, answer, timestamp)
        VALUES (?, ?, ?, ?, ?)
    """, (
        question_id,
        request.document_id,
        request.question,
        answer,
        datetime.now().isoformat()
    ))
    conn.commit()
    conn.close()
    
    return QuestionResponse(
        id=question_id,
        question=request.question,
        answer=answer,
        timestamp=datetime.now().isoformat()
    )

@app.get("/documents", response_model=List[DocumentResponse])
async def get_documents():
    """Get list of uploaded documents"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, filename, original_filename, upload_date, file_size FROM documents ORDER BY upload_date DESC")
    results = cursor.fetchall()
    conn.close()
    
    return [
        DocumentResponse(
            id=row[0],
            filename=row[1],
            original_filename=row[2],
            upload_date=row[3],
            file_size=row[4]
        )
        for row in results
    ]

@app.get("/documents/{document_id}/questions", response_model=List[QuestionResponse])
async def get_document_questions(document_id: str):
    """Get questions and answers for a specific document"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, question, answer, timestamp 
        FROM questions 
        WHERE document_id = ? 
        ORDER BY timestamp DESC
    """, (document_id,))
    results = cursor.fetchall()
    conn.close()
    
    return [
        QuestionResponse(
            id=row[0],
            question=row[1],
            answer=row[2],
            timestamp=row[3]
        )
        for row in results
    ]

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "message": "PDF Q&A API is running"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)