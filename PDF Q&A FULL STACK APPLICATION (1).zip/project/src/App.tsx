import React, { useState, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { FileText, MessageSquare, Upload } from 'lucide-react';
import DocumentUpload from './components/DocumentUpload';
import DocumentList from './components/DocumentList';
import QuestionInterface from './components/QuestionInterface';
import { Document } from './types';

function App() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'documents' | 'qa'>('upload');

  const fetchDocuments = async () => {
    try {
      const response = await fetch('http://localhost:8000/documents');
      if (response.ok) {
        const docs = await response.json();
        setDocuments(docs);
      }
    } catch (error) {
      console.error('Error fetching documents:', error);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const handleDocumentUploaded = () => {
    fetchDocuments();
    setActiveTab('documents');
  };

  const handleDocumentSelect = (document: Document) => {
    setSelectedDocument(document);
    setActiveTab('qa');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <FileText className="h-12 w-12 text-indigo-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-800">PDF Q&A Assistant</h1>
          </div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Upload PDF documents and ask questions about their content using natural language processing
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg shadow-md p-1 flex">
            <button
              onClick={() => setActiveTab('upload')}
              className={`flex items-center px-6 py-3 rounded-md font-medium transition-colors ${
                activeTab === 'upload'
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <Upload className="h-5 w-5 mr-2" />
              Upload PDF
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`flex items-center px-6 py-3 rounded-md font-medium transition-colors ${
                activeTab === 'documents'
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              <FileText className="h-5 w-5 mr-2" />
              Documents ({documents.length})
            </button>
            <button
              onClick={() => setActiveTab('qa')}
              disabled={!selectedDocument}
              className={`flex items-center px-6 py-3 rounded-md font-medium transition-colors ${
                activeTab === 'qa' && selectedDocument
                  ? 'bg-indigo-600 text-white'
                  : selectedDocument
                  ? 'text-gray-600 hover:text-gray-800'
                  : 'text-gray-400 cursor-not-allowed'
              }`}
            >
              <MessageSquare className="h-5 w-5 mr-2" />
              Ask Questions
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-4xl mx-auto">
          {activeTab === 'upload' && (
            <DocumentUpload onDocumentUploaded={handleDocumentUploaded} />
          )}
          
          {activeTab === 'documents' && (
            <DocumentList
              documents={documents}
              onDocumentSelect={handleDocumentSelect}
              selectedDocument={selectedDocument}
            />
          )}
          
          {activeTab === 'qa' && selectedDocument && (
            <QuestionInterface document={selectedDocument} />
          )}
          
          {activeTab === 'qa' && !selectedDocument && (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <MessageSquare className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-700 mb-2">
                No Document Selected
              </h3>
              <p className="text-gray-500">
                Please select a document from the Documents tab to start asking questions.
              </p>
            </div>
          )}
        </div>
      </div>
      <Toaster position="bottom-right" />
    </div>
  );
}

export default App;