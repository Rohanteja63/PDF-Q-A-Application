import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { Product } from '../types';
import toast from 'react-hot-toast';

const products: Product[] = [
  {
    id: 1,
    name: "Eco-Friendly Water Bottle",
    price: 24.99,
    image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500",
    description: "Sustainable stainless steel water bottle"
  },
  {
    id: 2,
    name: "Bamboo Utensil Set",
    price: 19.99,
    image: "https://images.unsplash.com/photo-1584346133934-a3c8d9e4daa9?w=500",
    description: "Reusable bamboo cutlery set"
  },
  {
    id: 3,
    name: "Organic Cotton Tote",
    price: 15.99,
    image: "https://images.unsplash.com/photo-1579657852324-56cb53a6a50a?w=500",
    description: "100% organic cotton shopping bag"
  },
  {
    id: 4,
    name: "Recycled Notebook",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1531346680769-a1d79b57de5c?w=500",
    description: "Made from 100% recycled paper"
  }
];

function Products() {
  const { addToCart } = useCart();

  const handleAddToCart = (product: Product) => {
    addToCart(product);
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Our Products</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-indigo-600">${product.price}</span>
                <button
                  onClick={() => handleAddToCart(product)}
                  className="flex items-center px-3 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  <ShoppingCart className="h-5 w-5 mr-1" />
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Products;