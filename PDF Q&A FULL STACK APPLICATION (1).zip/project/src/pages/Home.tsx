import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag } from 'lucide-react';

function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
      <div className="max-w-3xl">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          Welcome to EcoShop
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Discover our curated collection of sustainable and eco-friendly products.
          Shop with confidence knowing you're making a positive impact.
        </p>
        <Link
          to="/products"
          className="inline-flex items-center px-8 py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <ShoppingBag className="mr-2 h-5 w-5" />
          Start Shopping
        </Link>
      </div>
      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 w-full">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Free Shipping</h3>
          <p className="text-gray-600">On orders over $50</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">Secure Payment</h3>
          <p className="text-gray-600">100% secure payment</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold mb-3">24/7 Support</h3>
          <p className="text-gray-600">Dedicated support</p>
        </div>
      </div>
    </div>
  );
}

export default Home;