import React, { useState } from 'react';
import { format } from 'date-fns';
import { Pencil, Trash2, GripVertical } from 'lucide-react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import toast from 'react-hot-toast';
import { Task } from '../types';
import { useTheme } from '../context/ThemeContext';

interface TaskItemProps {
  task: Task;
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

function TaskItem({ task, setTasks }: TaskItemProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedTitle, setEditedTitle] = useState(task.title);
  const { theme } = useTheme();

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const priorityColors = {
    high: 'text-red-600',
    medium: 'text-yellow-600',
    low: 'text-green-600',
  };

  const handleToggleComplete = () => {
    setTasks(prev =>
      prev.map(t =>
        t.id === task.id ? { ...t, completed: !t.completed } : t
      )
    );
  };

  const handleDelete = () => {
    setTasks(prev => prev.filter(t => t.id !== task.id));
    toast.success('Task deleted successfully');
  };

  const handleEdit = () => {
    if (!editedTitle.trim()) {
      toast.error('Task title cannot be empty');
      return;
    }

    setTasks(prev =>
      prev.map(t =>
        t.id === task.id ? { ...t, title: editedTitle.trim() } : t
      )
    );
    setIsEditing(false);
    toast.success('Task updated successfully');
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`flex items-center gap-4 p-4 rounded-lg ${
        theme === 'dark' ? 'bg-gray-800' : 'bg-white shadow-sm'
      }`}
    >
      <div {...attributes} {...listeners}>
        <GripVertical className="h-5 w-5 cursor-grab text-gray-400" />
      </div>
      <input
        type="checkbox"
        checked={task.completed}
        onChange={handleToggleComplete}
        className="h-5 w-5 rounded border-gray-300"
      />
      <div className="flex-1">
        {isEditing ? (
          <input
            type="text"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
            onBlur={handleEdit}
            onKeyPress={(e) => e.key === 'Enter' && handleEdit()}
            className={`w-full px-2 py-1 rounded ${
              theme === 'dark'
                ? 'bg-gray-700 text-white'
                : 'bg-gray-50 text-gray-900'
            }`}
            autoFocus
          />
        ) : (
          <div className="flex flex-col">
            <span className={task.completed ? 'line-through text-gray-500' : ''}>
              {task.title}
            </span>
            <div className="flex items-center gap-2 mt-1">
              <span className={`text-sm ${priorityColors[task.priority]}`}>
                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
              </span>
              {task.dueDate && (
                <span className="text-sm text-gray-500">
                  Due: {format(new Date(task.dueDate), 'MMM d, yyyy')}
                </span>
              )}
            </div>
          </div>
        )}
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => setIsEditing(!isEditing)}
          className={`p-1 rounded hover:bg-gray-100 ${
            theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
          }`}
        >
          <Pencil className="h-4 w-4 text-gray-500" />
        </button>
        <button
          onClick={handleDelete}
          className={`p-1 rounded hover:bg-gray-100 ${
            theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
          }`}
        >
          <Trash2 className="h-4 w-4 text-red-500" />
        </button>
      </div>
    </div>
  );
}

export default TaskItem;