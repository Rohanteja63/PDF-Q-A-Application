import React from 'react';
import { useTheme } from '../context/ThemeContext';

interface FilterBarProps {
  filter: 'all' | 'active' | 'completed';
  setFilter: (filter: 'all' | 'active' | 'completed') => void;
  priorityFilter: 'all' | 'high' | 'medium' | 'low';
  setPriorityFilter: (filter: 'all' | 'high' | 'medium' | 'low') => void;
}

function FilterBar({ filter, setFilter, priorityFilter, setPriorityFilter }: FilterBarProps) {
  const { theme } = useTheme();

  return (
    <div className="flex flex-col md:flex-row gap-4 mb-6">
      <div className="flex rounded-lg overflow-hidden border divide-x">
        {(['all', 'active', 'completed'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 capitalize ${
              filter === f
                ? 'bg-indigo-600 text-white'
                : theme === 'dark'
                ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            {f}
          </button>
        ))}
      </div>
      <select
        value={priorityFilter}
        onChange={(e) => setPriorityFilter(e.target.value as 'all' | 'high' | 'medium' | 'low')}
        className={`px-4 py-2 rounded-lg border ${
          theme === 'dark'
            ? 'bg-gray-800 border-gray-700 text-white'
            : 'bg-white border-gray-300'
        }`}
      >
        <option value="all">All Priorities</option>
        <option value="high">High Priority</option>
        <option value="medium">Medium Priority</option>
        <option value="low">Low Priority</option>
      </select>
    </div>
  );
}

export default FilterBar;