import React from 'react';
import { CheckSquare, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

function Header() {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="flex items-center justify-between mb-8">
      <div className="flex items-center space-x-3">
        <CheckSquare className="h-8 w-8 text-indigo-600" />
        <h1 className="text-3xl font-bold">Task Manager Pro</h1>
      </div>
      <button
        onClick={toggleTheme}
        className={`p-2 rounded-lg ${
          theme === 'dark' 
            ? 'bg-gray-700 hover:bg-gray-600' 
            : 'bg-gray-200 hover:bg-gray-300'
        }`}
      >
        {theme === 'dark' ? (
          <Sun className="h-5 w-5" />
        ) : (
          <Moon className="h-5 w-5" />
        )}
      </button>
    </header>
  );
}

export default Header;