import React from 'react';
import { Target } from 'lucide-react';

interface PredictionResultProps {
  score: number;
}

function PredictionResult({ score }: PredictionResultProps) {
  return (
    <div className="mt-8 p-6 bg-gray-50 rounded-lg border-2 border-blue-100">
      <div className="flex items-center justify-center mb-4">
        <Target className="h-8 w-8 text-blue-600 mr-2" />
        <h2 className="text-2xl font-semibold text-gray-800">Predicted Score</h2>
      </div>
      <div className="text-center">
        <p className="text-5xl font-bold text-blue-600">{score}</p>
        <p className="mt-2 text-gray-600">Estimated final score based on current match situation</p>
      </div>
    </div>
  );
}

export default PredictionResult;