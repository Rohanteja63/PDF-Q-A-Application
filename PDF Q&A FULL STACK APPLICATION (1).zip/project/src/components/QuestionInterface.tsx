import React, { useState, useEffect } from 'react';
import { Send, MessageSquare, Bot, User, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { Document, Question } from '../types';

interface QuestionInterfaceProps {
  document: Document;
}

function QuestionInterface({ document }: QuestionInterfaceProps) {
  const [question, setQuestion] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchQuestions = async () => {
    try {
      const response = await fetch(`http://localhost:8000/documents/${document.id}/questions`);
      if (response.ok) {
        const data = await response.json();
        setQuestions(data);
      }
    } catch (error) {
      console.error('Error fetching questions:', error);
    }
  };

  useEffect(() => {
    fetchQuestions();
  }, [document.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim()) {
      toast.error('Please enter a question');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:8000/ask', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          document_id: document.id,
          question: question.trim(),
        }),
      });

      if (response.ok) {
        const result = await response.json();
        setQuestions(prev => [result, ...prev]);
        setQuestion('');
        toast.success('Question answered successfully!');
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to get answer');
      }
    } catch (error) {
      toast.error('Network error. Please check if the backend server is running.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <MessageSquare className="h-8 w-8 text-indigo-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Ask Questions</h2>
            <p className="text-gray-600">Document: {document.original_filename}</p>
          </div>
        </div>
      </div>

      {/* Question Form */}
      <div className="p-6 border-b border-gray-200">
        <form onSubmit={handleSubmit} className="flex space-x-4">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask a question about the document content..."
            className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !question.trim()}
            className="px-6 py-3 bg-indigo-600 text-white font-medium rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            {isLoading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </button>
        </form>
      </div>

      {/* Questions and Answers */}
      <div className="p-6">
        {questions.length === 0 ? (
          <div className="text-center py-8">
            <Bot className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-700 mb-2">No Questions Yet</h3>
            <p className="text-gray-500">
              Ask your first question about the document content above.
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {questions.map((qa) => (
              <div key={qa.id} className="space-y-4">
                {/* Question */}
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-indigo-600" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="bg-indigo-50 rounded-lg p-4">
                      <p className="text-gray-800">{qa.question}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatTimestamp(qa.timestamp)}
                    </p>
                  </div>
                </div>

                {/* Answer */}
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Bot className="h-5 w-5 text-green-600" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-gray-800 whitespace-pre-wrap">{qa.answer}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default QuestionInterface;