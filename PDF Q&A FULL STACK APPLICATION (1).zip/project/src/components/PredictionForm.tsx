import React, { useState } from 'react';
import toast from 'react-hot-toast';

interface PredictionFormProps {
  setPredictedScore: (score: number) => void;
}

function PredictionForm({ setPredictedScore }: PredictionFormProps) {
  const [formData, setFormData] = useState({
    currentScore: '',
    overs: '',
    wickets: '',
    lastFiveOvers: '',
    battingTeam: 'MI',
    bowlingTeam: 'CSK',
  });

  const teams = ['MI', 'CSK', 'RCB', 'KKR', 'SRH', 'PBKS', 'RR', 'DC'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // In a real application, this would call your ML model API
      // For demo purposes, using a simple calculation
      const currentScore = parseInt(formData.currentScore);
      const overs = parseFloat(formData.overs);
      const wickets = parseInt(formData.wickets);
      const lastFiveOvers = parseInt(formData.lastFiveOvers);
      
      if (overs > 20 || wickets > 10) {
        toast.error('Invalid overs or wickets value');
        return;
      }

      // Simple prediction logic (replace with actual ML model)
      const remainingOvers = 20 - overs;
      const avgRunRate = currentScore / overs;
      const projectedScore = currentScore + (remainingOvers * (avgRunRate + (lastFiveOvers/5 - avgRunRate)/2));
      
      setPredictedScore(Math.round(projectedScore));
      toast.success('Prediction generated successfully!');
    } catch (error) {
      toast.error('Error generating prediction');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Current Score
          </label>
          <input
            type="number"
            value={formData.currentScore}
            onChange={(e) => setFormData({ ...formData, currentScore: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            required
            min="0"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Overs Completed
          </label>
          <input
            type="number"
            value={formData.overs}
            onChange={(e) => setFormData({ ...formData, overs: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            required
            step="0.1"
            min="0"
            max="20"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Wickets
          </label>
          <input
            type="number"
            value={formData.wickets}
            onChange={(e) => setFormData({ ...formData, wickets: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            required
            min="0"
            max="10"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Runs in Last 5 Overs
          </label>
          <input
            type="number"
            value={formData.lastFiveOvers}
            onChange={(e) => setFormData({ ...formData, lastFiveOvers: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            required
            min="0"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Batting Team
          </label>
          <select
            value={formData.battingTeam}
            onChange={(e) => setFormData({ ...formData, battingTeam: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {teams.map((team) => (
              <option key={team} value={team}>{team}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Bowling Team
          </label>
          <select
            value={formData.bowlingTeam}
            onChange={(e) => setFormData({ ...formData, bowlingTeam: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            {teams.filter(team => team !== formData.battingTeam).map((team) => (
              <option key={team} value={team}>{team}</option>
            ))}
          </select>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
      >
        Predict Score
      </button>
    </form>
  );
}

export default PredictionForm;