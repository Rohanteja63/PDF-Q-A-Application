import React from 'react';
import { FileText, Calendar, HardDrive, ChevronRight } from 'lucide-react';
import { Document } from '../types';

interface DocumentListProps {
  documents: Document[];
  onDocumentSelect: (document: Document) => void;
  selectedDocument: Document | null;
}

function DocumentList({ documents, onDocumentSelect, selectedDocument }: DocumentListProps) {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (documents.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-700 mb-2">No Documents Uploaded</h3>
        <p className="text-gray-500">
          Upload your first PDF document to get started with Q&A.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold text-gray-800">Uploaded Documents</h2>
        <p className="text-gray-600 mt-1">
          Select a document to start asking questions about its content
        </p>
      </div>

      <div className="divide-y divide-gray-200">
        {documents.map((document) => (
          <div
            key={document.id}
            onClick={() => onDocumentSelect(document)}
            className={`p-6 hover:bg-gray-50 cursor-pointer transition-colors ${
              selectedDocument?.id === document.id ? 'bg-indigo-50 border-l-4 border-indigo-500' : ''
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <FileText className="h-8 w-8 text-indigo-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-medium text-gray-900 truncate">
                    {document.original_filename}
                  </h3>
                  <div className="mt-2 flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(document.upload_date)}
                    </div>
                    <div className="flex items-center">
                      <HardDrive className="h-4 w-4 mr-1" />
                      {formatFileSize(document.file_size)}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex-shrink-0">
                <ChevronRight className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default DocumentList;