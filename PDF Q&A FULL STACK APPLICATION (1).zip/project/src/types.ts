export interface Document {
  id: string;
  filename: string;
  original_filename: string;
  upload_date: string;
  file_size: number;
}

export interface Question {
  id: string;
  question: string;
  answer: string;
  timestamp: string;
}